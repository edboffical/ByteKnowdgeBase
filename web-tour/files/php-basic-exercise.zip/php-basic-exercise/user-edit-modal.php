<?php

require 'includes/functions.inc.php';

// @todo 通过在 users.php 页面上 点击 "编辑"，通过 Ajax GET 的方式加载此文件，显示模态框。

// @todo 在模态框中，点击“保存”按钮时，触发 Ajax POST 请求，提交数据。
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // @todo: 校验数据，如果非法，则输出JSON {"status": "error", "message": "数据格式不正确！"}，前端收到此回应后，在模态框的头部区域显示此错误消息。
    // @todo: 保存用户信息。
    // @todo: 保存失败，则输出 JSON {"status": "error", "message": "保存用户信息失败！"}，前端收到此回应后，在模态框的头部区域显示此错误消息。
    // @todo: 保存成功，则输出 JSON {"status": "ok"}，前端收到此回应后，重载页面，在页面头部区域，显示“编辑用户成功！“的消息提示。 
} else {
    // @todo 判断是否为管理员，如果不是，则在输出的模态框中，用 `alert-danger`组件显示“您无权操作！"的错误提示。
    // @todo 如果是，则根据传入的`id`参数， 在数据文件中找到该用户，设置到 $user 变量。
    // @todo 将 $user 变量的信息填入各个输入框后，输出编辑用户信息的模态框 HTML。
    require 'templates/user-edit-modal.html.php';
}
