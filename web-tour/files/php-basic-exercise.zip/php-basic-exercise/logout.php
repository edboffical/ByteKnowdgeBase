<?php
/**
 * 此文件为"退出登录"的代码
 */

 require 'includes/functions.inc.php';

 //@todo 逻辑请自行实现