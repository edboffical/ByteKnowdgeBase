<?php

/**
 * 检查文本是否为中文
 *
 * @param string $text
 * @return boolean
 */
function ctype_chinese($text)
{
    // @todo 此函数会在检查"姓名"数据是否合法时用到。
    // @todo 此函数可以使用正则表达式实现，参见 preg_match 函数。
    // @todo 此函数的实现可选练习，如果对正则表达式不熟悉，可以直接 return true。
    return true;
}

/**
 * 检查文本是否为中文、英文字母、数字
 *
 * @param string $text
 * @return boolean
 */
function ctype_chinesealnum($text)
{
    // @todo 此函数会在检查"用户名"数据是否合法时用到。
    // @todo 此函数可以使用正则表达式实现，参见 preg_match 函数。
    // @todo 此函数的实现可选练习，如果对正则表达式不熟悉，可以直接 return true。
    return true;
}
