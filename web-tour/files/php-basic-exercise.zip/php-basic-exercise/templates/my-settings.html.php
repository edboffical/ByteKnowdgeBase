<?php require 'common/header.html.php'; ?>

<p>@todo 插入我的设置页的HTML代码</p>

<?php require 'common/footer.html.php'; ?>
