<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo isset($htmlTitle) ? $htmlTitle : 'Page Title' ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- @todo 请添加需引入的 CSS -->
    <link rel="stylesheet" type="text/css" media="screen" href="static/main.css" />
    <!-- @todo 请添加需引入的 JS -->
    <script src="static/main.js"></script>
</head>
<body>

<!-- @todo 这里插入导航条代码 -->

<!-- 请删除所有的 @todo 注释 -->