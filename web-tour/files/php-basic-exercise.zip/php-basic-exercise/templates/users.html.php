<?php require 'common/header.html.php'; ?>

<p>@todo 插入"用户管理页的HTML代码</p>

<?php require 'common/footer.html.php'; ?>
