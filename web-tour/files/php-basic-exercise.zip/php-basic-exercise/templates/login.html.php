<?php require 'common/header.html.php'; ?>

<p>@todo 请插入登陆页的HTML代码</p>

<?php require 'common/footer.html.php'; ?>
